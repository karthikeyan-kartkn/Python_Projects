from tkinter import *
from PIL import ImageTk,Image
import pdfkit
import datetime
paths=r"C:\Program Files\wkhtmltopdf\bin\wkhtmltopdf.exe"
config=pdfkit.configuration(wkhtmltopdf=paths)

top=Tk()
top.title("PDF Converter")
top.geometry("1000x600")
filename=Image.open('C:\\Users\\sneha\\OneDrive\\Desktop\\PDF-Icon.PNG')
resized=filename.resize((300,225),Image.ANTIALIAS)
filename1=ImageTk.PhotoImage(resized)
label= Label(top,image=filename1)
label.place(x=400,y=120)
top.title("Link To PDF Conventer")
Label(top,text = 'PDF Conventer', font ='arial 20 bold').place(x=470,y=10)
link = StringVar()
Label(top, text = 'Paste Link Here:', font = 'arial 15 bold').place(x=20 , y = 40)
link_enter = Entry(top, width = 140,textvariable = link)
link_enter.place(x = 120, y = 90)

def clear_text():
   link_enter.delete(0, END)

def CONVERT():
    pdfkit.from_url(link.get(),r'Converted PDF.pdf',configuration=config)
    Label(top, text='Your Link is Converted', font='arial 15').place(x=480, y=380)
button = Button(top , text = "Convert" , command = CONVERT , font = 'arial 15 bold' ,bg = 'pale violet red', padx = 1).place(x=520 ,y = 400)
Button(top,height=0,width=4,text="Clear", font = 'arial 14 bold' ,bg = 'red',command=clear_text).place(x = 1000, y = 78)
top.mainloop()
 
