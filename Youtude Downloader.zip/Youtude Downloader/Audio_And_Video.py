from tkinter import *
from pytube import YouTube

root = Tk()
root.geometry('1000x600')
root.resizable(0,0)
root.title("U-Downs")
Label(root,text = 'Youtube Video Downloader', font ='arial 20 bold').pack()
link = StringVar()
Label(root, text = 'Paste Link Here:', font = 'arial 15 bold').place(x= 400 , y = 60)
link_enter = Entry(root, width = 140,textvariable = link)
link_enter.place(x = 90, y = 90)

def clear_text():
   link_enter.delete(0, END)

def Vid_Downloader():
    YouTube(str(link.get())).streams.get_highest_resolution().download('C://Users//Cva//Downloads//U-DOWNS//VIDEO')
    Label(root, text = 'VIDEO DOWNLOADED', font = 'arial 15').place(x= 380 , y = 270)

def Aud_Downloader():
    YouTube(str(link.get())).streams.last().download('C://Users//Cva//Downloads//U-DOWNS//AUDIO')
    Label(root, text = 'AUDIO DOWNLOADED', font = 'arial 15').place(x= 380 , y = 270)

def DOWN_MINE():
    options = [
        str(i).split()[3].replace("abr=", "").replace("res=", "").replace("<", "").replace(">", "").replace("kbps",
                                                                                                            "_KBPS - AUDIO").replace(
            'p"', "_P - VIDEO").replace('"', "") for i in
        YouTube(str(link.get())).streams]
    options1 = [str(i).split(" ")[1].replace("itag=", "").replace('"', "") for i in YouTube(str(link.get())).streams]
    indexx=options1[options.index(str(clicked.get()))]
    YouTube(str(link.get())).streams.get_by_itag(indexx).download('C://Users//Cva//Downloads//U-DOWNS//')
    Label(root, text='UR CHOICE DOWNLOADED', font='arial 15').place(x=380, y=270)

def LOAD():
    options = [
        str(i).split()[3].replace("abr=", "").replace("res=", "").replace("<", "").replace(">", "").replace("kbps",
                                                                                                            "_KBPS - AUDIO").replace(
            'p"', "_P - VIDEO").replace('"', "") for i in
        YouTube(str(link.get())).streams]
    drop = OptionMenu(root, clicked, *options).place(x=320, y=380)
    button = Button(root, text="DOWNLOAD MY CHOICE",  font='arial 15 bold', command = DOWN_MINE, bg='pale violet red',
                    padx=1).place(x=500, y=370)

clicked = StringVar()
clicked.set("CHOOSE UR CHOICE")
button = Button(root , text = "SHOW ME CHOICE" , command = LOAD , font = 'arial 15 bold' ,bg = 'pale violet red', padx = 1).place(x=390 ,y = 300)
Button(root,text = 'GET BEST VIDEO', font = 'arial 15 bold' ,bg = 'pale violet red', padx = 1, command = Vid_Downloader).place(x=250 ,y = 165)
Button(root,text = 'GET BEST AUDIO', font = 'arial 15 bold' ,bg = 'pale violet red', padx = 1, command = Aud_Downloader).place(x=542 ,y = 165)
Button(root,height=0,width=5,text="Clear", font = 'arial 15 bold' ,bg = 'red',command=clear_text).place(x = 450, y = 120)
root.mainloop()

